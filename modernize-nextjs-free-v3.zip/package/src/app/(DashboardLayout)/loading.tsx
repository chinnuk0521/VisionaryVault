const Loading = () =>{
    return(
        <div>Dash Loading</div>
    )
}

export default Loading;